﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaintBrush : MonoBehaviour
{
    /// <summary>
    /// Debug stuff
    /// </summary>
    public Renderer editorRenderer;
    public Texture2D editorTexture2D;

    public int resolution = 512;
    Texture2D whiteMap;
    public float brushSize;
    public Texture2D brushTexture;
    Vector2 stored;
    public static Dictionary<Collider, RenderTexture> paintTextures = new Dictionary<Collider, RenderTexture>();
    void Start()
    {
        CreateClearTexture();// clear white texture to draw on
    }

    void Update()
    {

        Debug.DrawRay(transform.position, Vector3.down * 20f, Color.magenta);
        RaycastHit hit;
        //if (Physics.Raycast(transform.position, Vector3.down, out hit))


        if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit) /*&& Input.GetKeyDown(KeyCode.Space)*/) // delete previous and uncomment for mouse painting
        {
            /// debug ray
            Debug.DrawRay(hit.point, (hit.normal * 5f), Color.magenta);

            editorRenderer = hit.transform.GetComponent<Renderer>();
            editorTexture2D = editorRenderer.material.GetTexture("_PaintMap") as Texture2D;
            //resolution = editorTexture2D.height;

            Vector2 pixelUV2 = hit.lightmapCoord;
            pixelUV2.y *= resolution;
            pixelUV2.x *= resolution;
            editorTexture2D.SetPixel((int)pixelUV2.x, (int)pixelUV2.y, Color.red);
            editorTexture2D.Apply();

            Collider coll = hit.collider;
            return;
            if (coll != null)
            {
                if (!paintTextures.ContainsKey(coll)) // if there is already paint on the material, add to that
                {
                    Renderer rend = hit.transform.GetComponent<Renderer>();
                    paintTextures.Add(coll, getWhiteRT());
                    rend.material.SetTexture("_PaintMap", paintTextures[coll]);


                }
                if (stored != hit.lightmapCoord) // stop drawing on the same point
                {

                    ///

                    
                   
                    stored = hit.lightmapCoord;
                    Vector2 pixelUV = hit.lightmapCoord;
                    pixelUV.y *= resolution;
                    pixelUV.x *= resolution;

                    ///
                    //editorTexture2D.SetPixel((int)pixelUV.x, (int)pixelUV.y, Color.red);
                    //editorTexture2D.Apply();




                    //DrawTexture(paintTextures[coll], pixelUV.x, pixelUV.y);






                }
            }
        }
    }

    void DrawTexture(RenderTexture rt, float posX, float posY)
    {
        RenderTexture.active = rt; // activate rendertexture for drawtexture;
        GL.PushMatrix();                       // save matrixes
        GL.LoadPixelMatrix(0, resolution, resolution, 0);      // setup matrix for correct size

        // draw brushtexture
        Graphics.DrawTexture(new Rect(posX - brushTexture.width / brushSize, (rt.height - posY) - brushTexture.height / brushSize, brushTexture.width / (brushSize * 0.5f), brushTexture.height / (brushSize * 0.5f)), brushTexture);
        GL.PopMatrix();
        RenderTexture.active = null;// turn off rendertexture


    }

    RenderTexture getWhiteRT()
    {
        RenderTexture rt = new RenderTexture(resolution, resolution, 32);
        Graphics.Blit(whiteMap, rt);
        return rt;
    }

    [AddComponentMenu("clear")]
    void CreateClearTexture()
    {
        whiteMap = new Texture2D(1, 1);
        whiteMap.SetPixel(0, 0, Color.white);
        whiteMap.Apply();
    }


}